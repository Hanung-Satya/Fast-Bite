<?php

$host = 'localhost';
$username = 'fastbite_user';
$password = 'Hanungsaw135$';
$dbname = 'fastbite_db';

$conn = mysqli_connect($host, $username, $password, $dbname);

if ($conn -> connect_error) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}
?>