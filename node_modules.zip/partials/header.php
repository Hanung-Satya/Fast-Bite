<header class="fixed">
    <div class="header-container">
        <a href="/FastBite/index.php#home" class="logo">Fast<span class="gradient-txt">Bite</span></a>
        <nav class="navbar">
            <ul class="ul-links">
                <li><a href="../index.php#home">Home</a></li>
                <li><a href="../index.php#whyUs">Why Us</a></li>
                <li><a href="../index.php#menu">Menu</a></li>

                <?php if (isset($_SESSION['user'])) : ?>
                    <li><a href="/FastBite/cart.php">
                            <i class="fa-solid fa-cart-shopping"></i>
                        </a></li>
                    <li class="user-dropdown relative">
                        <a id="user-icon" href="#" class="text-xl">
                            <i class="fa-solid fa-circle-user"></i>
                        </a>
                        <ul class="dropdown-menu absolute right-0 top-8 bg-white border border-gray-200 rounded-lg shadow-lg z-50" hidden>
                            <li>
                                <a href="/FastBite/auth/logout.php" class="outline-btn rounded-lg flex items-center justify-center gap-2 text-sm py-1 px-3">
                                    <i class="fa-solid fa-right-from-bracket "></i>Logout 
                                </a>
                            </li>
                        </ul>
                    </li>

                <?php else : ?>
                    <li><a href="../auth/login.php" class="fill-btn">Sign In</a></li>
                    <li><a href="../auth/register.php" class="outline-btn">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>